from __future__ import print_function

import torch
import torch.nn as nn


class DualTempSupConLoss(nn.Module):
    """Supervised Contrastive Loss with Dual Temperature for Long-Tail Learning"""

    def __init__(self, cls_num_list=None, temperature=0.07, contrast_mode='all',
                 base_temperature=0.07, head_ratio=0.3, temp_ratio=0.5):
        super().__init__()
        self.temperature = temperature
        self.contrast_mode = contrast_mode
        self.base_temperature = base_temperature
        self.cls_num_list = cls_num_list
        self.temp_ratio = temp_ratio

        # 自动识别头部类别（按样本数排序）
        if cls_num_list is not None:
            sorted_idx = torch.argsort(torch.tensor(cls_num_list), descending=True)
            self.num_head = int(len(cls_num_list) * head_ratio)
            self.head_classes = sorted_idx[:self.num_head]

            # 修改点1：确保head_mask在创建时就转移到当前设备
            self.register_buffer('head_mask',
                                 torch.zeros(len(cls_num_list), dtype=torch.bool))
            self.head_mask[self.head_classes] = True
        else:
            self.register_buffer('head_mask', None)

    def forward(self, features, labels, mask=None):
        device = features.device  # 获取特征所在的设备

        # 修改点2：确保head_mask与labels同设备
        if self.head_mask is not None:
            self.head_mask = self.head_mask.to(device)

        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)

        batch_size = features.shape[0]

        # 处理标签和掩码
        if labels is not None and mask is not None:
            raise ValueError('Cannot define both `labels` and `mask`')
        elif labels is None and mask is None:
            mask = torch.eye(batch_size, dtype=torch.float32).to(device)
        elif labels is not None:
            labels = labels[:, 0] if len(labels.shape) > 1 else labels
            labels = labels.contiguous().view(-1, 1).to(device)  # 确保labels在正确设备
            targets = labels.contiguous().view(-1, 1)
            if labels.shape[0] != batch_size:
                raise ValueError('Num of labels does not match num of features')
        else:
            mask = mask.float().to(device)

        contrast_count = features.shape[1]
        contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)

        # 双温度系数分配
        if self.head_mask is not None:
            # 修改点3：确保所有张量同设备
            is_head = self.head_mask[labels.squeeze().long()]  # 显式转换为long
            head_temp = torch.tensor(self.temperature * (1 + self.temp_ratio), device=device)
            tail_temp = torch.tensor(self.temperature * (1 - self.temp_ratio), device=device)
            temps = torch.where(is_head.repeat(contrast_count), head_temp, tail_temp)
        else:
            temps = torch.full((contrast_count * batch_size,), self.temperature, device=device)

        # 剩余代码保持不变...
        # ... [保持原有计算逻辑，确保所有操作都在device上]

        # 计算相似度
        if self.contrast_mode == 'one':
            anchor_feature = features[:, 0]
            anchor_count = 1
        elif self.contrast_mode == 'all':
            anchor_feature = contrast_feature
            anchor_count = contrast_count
        else:
            raise ValueError('Unknown mode: {}'.format(self.contrast_mode))

        targets = targets.long()
        targets = targets.repeat(anchor_count, 1)

        # 温度加权的相似度计算
        anchor_dot_contrast = torch.matmul(anchor_feature, contrast_feature.T)
        anchor_dot_contrast = torch.div(anchor_dot_contrast, temps.unsqueeze(1))  # 行方向温度加权

        # 数值稳定性处理
        logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
        logits = anchor_dot_contrast - logits_max.detach()

        # 正样本掩码
        mask = torch.eq(targets[:batch_size * anchor_count], targets.T).float().to(device)
        logits_mask = torch.scatter(
            torch.ones_like(mask),
            1,
            torch.arange(batch_size * anchor_count).view(-1, 1).to(device),
            0
        )
        mask = mask * logits_mask

        # 类别平衡权重
        if self.cls_num_list is not None:
            batch_cls_count = torch.eye(len(self.cls_num_list)).to(device)[targets].sum(dim=0).squeeze()
            per_ins_weight = torch.tensor([batch_cls_count[i] for i in targets],
                                          device=device).view(1, -1).expand(
                batch_size * anchor_count,
                batch_size * anchor_count) - mask
            exp_logits = torch.exp(logits) * logits_mask
            exp_logits_sum = exp_logits.div(per_ins_weight + 1e-8).sum(dim=1, keepdim=True)
        else:
            exp_logits = torch.exp(logits) * logits_mask
            exp_logits_sum = exp_logits.sum(dim=1, keepdim=True)

        log_prob = logits - torch.log(exp_logits_sum + 1e-8)

        # 损失计算
        mean_log_prob_pos = (mask * log_prob).sum(1) / (mask.sum(1) + 1e-8)
        loss = -mean_log_prob_pos
        loss = loss.view(anchor_count, batch_size).mean()

        return loss