import clip
from PIL import Image
import torch
import warnings
import os
import argparse
import warnings
from coop_model import *
from datasets import build_dataset
import tqdm
from torch.autograd import Variable
from metrics import *
import matplotlib.pyplot as plt
from torchvision import transforms

warnings.filterwarnings('ignore')


def get_args_parser():
    parser = argparse.ArgumentParser('auto-prompt clip', add_help=False)
    parser.add_argument('--device', default='cuda', help='device to use for training / testing')
    parser.add_argument('--seed', default='0', type=int, help='seed')
    parser.add_argument('--pretrain_clip', default='RN50', type=str, choices=['RN50', 'ViT16', 'ViT32'],
                        help='pretrained clip backbone')
    parser.add_argument('--batch_size', default=32, type=int, help='batch size')
    parser.add_argument('--dataset', default='voc-lt', type=str, choices=['coco-lt', 'voc-lt'])
    parser.add_argument('--ctx_init', default='This is a photo of a specific item', type=str, help='init context prompt')
    parser.add_argument('--n_ctx', default=8, type=int, help='length of context prompt when initializing')
    parser.add_argument('--class_token_position', default='end', type=str, help='position of class token')
    parser.add_argument('--training_method', default='lmpt', type=str, choices=['coop', 'cocoop', 'dualcoop', 'lmpt'],
                        help='training method (coop cocoop)')
    parser.add_argument('--csc', action='store_true', default=False,
                        help='class-specific contexts (if False then initialize a generic context)')
    parser.add_argument('--thre', default=0.0, type=float, help='threshold value')
    return parser


def analyze_single_image(args, model, image_path, dataset_classes):
    """纯预测模式（无GT对比）的多标签分类分析"""
    # 图像预处理（保持不变）
    preprocess = transforms.Compose([
        transforms.Resize(224, interpolation=transforms.InterpolationMode.BICUBIC),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # 加载图像
    image = Image.open(image_path).convert("RGB")
    image_input = preprocess(image).unsqueeze(0).to(args.device)

    # 模型预测
    model.eval()
    with torch.no_grad():
        logits_per_image, _, __ = model(image_input)
        sf = nn.Softmax(dim=1)
        logits_per_image = sf(logits_per_image).cpu()
        probs = logits_per_image.numpy()[0]

    # 过滤无效标签（关键改进！）
    valid_indices = [
        i for i, cls in enumerate(dataset_classes)
        if cls.isalpha() and len(cls) > 2  # 过滤乱码（如"shen"）
    ]
    filtered_classes = [dataset_classes[i] for i in valid_indices]
    filtered_probs = probs[valid_indices]

    # 获取预测结果（基于阈值）
    pred_labels = (filtered_probs > args.thre).astype(int)

    # 可视化（仅显示有效标签）
    plt.figure(figsize=(16, 12))

    # 1. 显示输入图像（左侧）
    plt.subplot(1, 2, 1)
    plt.imshow(image)
    plt.axis('off')
    plt.title("Input Image", fontsize=14, pad=20)

    # 2. 优化后的概率分布图（右侧）
    ax = plt.subplot(1, 2, 2)

    # 只显示预测概率>threshold的类别
    valid_idx = np.where(probs > args.thre)[0]
    filtered_classes = [dataset_classes[i] for i in valid_idx]
    filtered_probs = probs[valid_idx]

    # 按概率值排序
    sort_idx = np.argsort(filtered_probs)
    y_pos = np.arange(len(filtered_classes))

    # 颜色映射（概率越高越红）
    colors = plt.cm.Reds(filtered_probs[sort_idx] * 0.7 + 0.3)

    # 绘制条形图
    bars = ax.barh(y_pos, filtered_probs[sort_idx], color=colors, height=0.6)

    # 标注文本设置
    for i, (prob, cls) in enumerate(zip(filtered_probs[sort_idx], np.array(filtered_classes)[sort_idx])):
        ax.text(prob + 0.02, i,
                f"{cls}: {prob:.3f}",
                va='center',
                fontsize=10,
                fontweight='bold' if prob > 0.7 else 'normal')

    # 坐标轴美化
    ax.set_yticks(y_pos)
    ax.set_yticklabels(np.array(filtered_classes)[sort_idx], fontsize=10)
    ax.set_xlim(0, 1.1)
    ax.set_xlabel("Prediction Probability", fontsize=12)
    ax.set_title("Filtered Predictions (threshold=0)", fontsize=14, pad=20)
    ax.grid(axis='x', alpha=0.3)

    # 添加阈值参考线
    ax.axvline(x=args.thre, color='gray', linestyle='--', alpha=0.5)
    ax.text(args.thre, len(filtered_classes) - 0.5,
            f'Threshold: {args.thre}',
            color='gray', ha='right')

    plt.tight_layout()
    plt.savefig('improved_visualization.png', dpi=300, bbox_inches='tight')
    plt.show()

def main(args):
    print(args)

    # fix the seed for reproducibility
    torch.manual_seed(args.seed)

    os.environ["CUDA_VISIBLE_DEVICES"] = '0'

    """ 
    model
    """
    if args.pretrain_clip == "RN50":
        pretrain_clip_path = '../pretrained/RN50.pt'
    elif args.pretrain_clip == "ViT16":
        pretrain_clip_path = '../pretrained/ViT-B-16.pt'

    print(f"Loading CLIP (backbone: {args.pretrain_clip})")
    clip_model, preprocess = clip.load(pretrain_clip_path, device='cpu', jit=False)  # Must set jit=False for training

    def convert_models_to_fp32(model):
        for p in model.parameters():
            p.data = p.data.float()
            p.grad.data = p.grad.data.float()

    clip.model.convert_weights(clip_model)  # Actually this line is unnecessary since clip by default already on float16

    if args.dataset == 'coco-lt':
        dataset_classes = [
            'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train',
            'truck', 'boat', 'traffic_light', 'fire_hydrant', 'stop_sign',
            'parking_meter', 'bench', 'bird', 'cat', 'dog', 'horse', 'sheep',
            'cow', 'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella',
            'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard',
            'sports_ball', 'kite', 'baseball_bat', 'baseball_glove', 'skateboard',
            'surfboard', 'tennis_racket', 'bottle', 'wine_glass', 'cup', 'fork',
            'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich', 'orange',
            'broccoli', 'carrot', 'hot_dog', 'pizza', 'donut', 'cake', 'chair',
            'couch', 'potted_plant', 'bed', 'dining_table', 'toilet', 'tv',
            'laptop', 'mouse', 'remote', 'keyboard', 'cell_phone', 'microwave',
            'oven', 'toaster', 'sink', 'refrigerator', 'book', 'clock', 'vase',
            'scissors', 'teddy_bear', 'hair_drier', 'toothbrush'
        ]
    elif args.dataset == 'voc-lt' or args.dataset == 'voc':
        dataset_classes = [
            'aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 'bus', 'car',
            'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', 'motorbike',
            'person', 'pottedplant', 'sheep', 'sofa', 'train', 'tvmonitor'
        ]

    print("Building custom CLIP")
    model = CustomCLIP(args, classnames=dataset_classes, clip_model=clip_model)
    model.to(args.device)
    if args.dataset == 'voc-lt':
        model.load_state_dict(torch.load('../checkpoint_voc/ctx_8_32_lmpt_RN50_voc-lt_asl_supcon_csc.pt'))
    elif args.dataset == 'coco-lt':
        model.load_state_dict(
            torch.load('../checkpoint_sigmoid/32_0.5_lmpt_RN50_coco-lt_asl_supcon_csc.pt'))
    model.add_module('sigmoid', torch.nn.Sigmoid())

    test_dataset = build_dataset(dataset=args.dataset, split='test')
    test_loader = torch.utils.data.DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        drop_last=False
    )
    image_path = "/home/kin/桌面/2007_005915.jpg"  # 替换为实际图片路径
    results = analyze_single_image(args, model, image_path, dataset_classes)

    # 打印结果
    print("\nSingle Image Analysis Results:")
    print("=" * 50)



if __name__ == '__main__':
    parser = argparse.ArgumentParser('auto-prompt clip', parents=[get_args_parser()])
    args = parser.parse_args()
    main(args)
