import os
import torch
import numpy as np
from torch.utils.data import DataLoader
from models import resnext
from dataset.cifar import IMBALANCECIFAR10
from torchvision import transforms, datasets
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import argparse

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', default='cifar', choices=['inat', 'imagenet','cifar'])
parser.add_argument('--data', default=r'E:\fengzheng\fz\cifar-10-python\cifar-10-batches-py', metavar='DIR')
parser.add_argument('--arch', default='resnet50', choices=['resnet50', 'resnext50'])
parser.add_argument('--workers', default=0, type=int)
parser.add_argument('--epochs', default=300, type=int)
parser.add_argument('--temp', default=0.07, type=float, help='scalar temperature for contrastive learning')
parser.add_argument('--start_epoch', default=0, type=int, metavar='N',
                    help='manual epoch number (useful on restarts)')
parser.add_argument('-b', '--batch-size', default=32, type=int,
                    metavar='N',
                    help='mini-batch size (default: 256), this is the total '
                         'batch size of all GPUs on the current node when '
                         'using Data Parallel or Distributed Data Parallel')
parser.add_argument('--lr', '--learning-rate', default=0.1, type=float,
                    metavar='LR', help='initial learning rate', dest='lr')
parser.add_argument('--schedule', default=[160, 180], nargs='*', type=int,
                    help='learning rate schedule (when to drop lr by 10x)')
parser.add_argument('--momentum', default=0.9, type=float, metavar='M',
                    help='momentum of SGD solver')
parser.add_argument('--wd', '--weight-decay', default=5e-4, type=float,
                    metavar='W', help='weight decay (default: 1e-4)',
                    dest='weight_decay')
parser.add_argument('-p', '--print-freq', default=20, type=int,
                    metavar='N', help='print frequency (default: 20)')
parser.add_argument('-e', '--evaluate', dest='evaluate', action='store_true',
                    help='evaluate model on validation set')
parser.add_argument('--resume', default='', type=str, metavar='PATH',
                    help='path to latest checkpoint (default: none)')
parser.add_argument('--gpu', default=None, type=int,
                    help='GPU id to use.')
parser.add_argument('--alpha', default=1.0, type=float, help='cross entropy loss weight')
parser.add_argument('--beta', default=0.35, type=float, help='supervised contrastive loss weight')
parser.add_argument('--randaug', default=True, type=bool, help='use RandAugmentation for classification branch')
parser.add_argument('--cl_views', default='sim-sim', type=str, choices=['sim-sim', 'sim-rand', 'rand-rand'],
                    help='Augmentation strategy for contrastive learning views')
parser.add_argument('--feat_dim', default=10, type=int, help='feature dimension of mlp head')
parser.add_argument('--warmup_epochs', default=0, type=int,
                    help='warmup epochs')
parser.add_argument('--root_log', type=str, default='log')
parser.add_argument('--cos', default=True, type=bool,
                    help='lr decays by cosine scheduler. ')
parser.add_argument('--use_norm', default=True, type=bool,
                    help='cosine classifier.')
parser.add_argument('--randaug_m', default=10, type=int, help='randaug-m')
parser.add_argument('--randaug_n', default=2, type=int, help='randaug-n')
parser.add_argument('--seed', default=None, type=int, help='seed for initializing training')
parser.add_argument('--reload', default=False, type=bool, help='load supervised model')
def extract_features(model, data_loader):
    features = []
    labels = []

    # 设置模型为评估模式
    model.eval()

    with torch.no_grad():
        for images, targets in data_loader:
            images = images.to(device)
            images = torch.cat([images, images, images], dim=0)
            targets = targets.to(device)

            # 提取中间层特征
            features_batch, feat_mlp, logits, centers = model(images)  # 根据模型中提取特征的方法进行调整
            features.append(features_batch)
            labels.append(targets)

    features = torch.cat(features, dim=0).cpu().numpy()
    labels = torch.cat(labels, dim=0).cpu().numpy()

    return features, labels

args = parser.parse_args()
# 加载测试数据
transform = transforms.Compose([
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),  # 转换为张量
        transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))  # 归一化
    ])
#data_root = os.path.abspath(os.path.join(os.getcwd(), "E:/test/VGG16_FPN/"))  # get data root path
#image_path = os.path.join(data_root, "data", "xian_data")  # flower data set path
#assert os.path.exists(image_path), "{} path does not exist.".format(image_path)
#test_dataset = datasets.ImageFolder(root=os.path.join(image_path, "test"),transform=test_transform)
val_dataset = IMBALANCECIFAR10(root=args.data, imb_type='exp', imb_factor=0.01, train=False, transform=transform,
                                   download=True)
test_loader = DataLoader(val_dataset, batch_size=8, shuffle=False)

test_steps = len(test_loader)
test_num = len(val_dataset)

# 加载训练好的模型权重
model = resnext.BCLModel(name='resnet50', num_classes=args.feat_dim, feat_dim=args.feat_dim,use_norm=args.use_norm)
model = torch.nn.DataParallel(model).cuda()

# 线阵数据集
# net.load_state_dict(torch.load('E:/test/VGG16_FPN/weight/CE/xian/model_500.pth'))
# net.load_state_dict(torch.load('E:/test/VGG16_FPN/weight/ce+center/xian/model_598.pth'))
# net.load_state_dict(torch.load('E:/test/VGG16_FPN/weight/focal+center/xian/model_487.pth'))
#model.load_state_dict(torch.load('./log/cifar_resnet50_batchsize_32_epochs_300_temp_0.07_lr_0.1_sim-sim/bcl_ckpt.pth'))
args.resume=r'E:\fengzheng\fz\又新Balanced-Contrastive-Learning\log\imagenet_resnet50_batchsize_32_epochs_300_temp_0.07_lr_0.1_sim-sim\bcl_ckpt.best.pth'
print("=> loading checkpoint '{}'".format(args.resume))
checkpoint = torch.load(args.resume, map_location='cuda:0')
#args.start_epoch = checkpoint['epoch']
best_acc1 = checkpoint['best_acc1']

model.load_state_dict(checkpoint['state_dict'])
#optimizer.load_state_dict(checkpoint['optimizer'])
print("=> loaded checkpoint '{}' (epoch {})"
      .format(args.resume, checkpoint['epoch']))

# 凸阵数据集
# net.load_state_dict(torch.load('E:/test/VGG16_FPN/weight/CE/tu/model_571.pth'))
# net.load_state_dict(torch.load('E:/test/VGG16_FPN/weight/ce+center/tu/model_599.pth'))
# net.load_state_dict(torch.load('E:/test/VGG16_FPN/weight/focal+center/tu/model_594.pth'))
# net.load_state_dict(torch.load('E:/test/VGG16_FPN/weight/ce-focal/tu-9/model_592.pth'))

# 提取测试数据集的特征
test_features, test_labels = extract_features(model, test_loader)

# 使用 t-SNE 降维
tsne = TSNE(n_components=2, random_state=0)
test_features_tsne = tsne.fit_transform(test_features)

# 设置每个类别的颜色和标签
'''num_classes = len(np.unique(test_labels))
colors = plt.cm.get_cmap('viridis', num_classes)
class_labels = ['{}'.format(i) for i in range(num_classes)]

# 可视化特征分布
# plt.figure(figsize=(10, 7))
for i in range(num_classes):
    indices = np.where(test_labels == i)
    plt.scatter(test_features_tsne[indices, 0], test_features_tsne[indices, 1], color=colors(i), label=class_labels[i], s=15)

plt.legend()
# plt.title('(a)')
# plt.xlabel('(a)')
# plt.xlabel('(b)')
# plt.xlabel('(c)')
plt.xlabel('(d)')

# 设置固定刻度
xticks = np.arange(-40, 50, 10)
yticks = np.arange(-40, 50, 10)
plt.xticks(xticks)
plt.yticks(yticks)
plt.show()'''
num_classes = len(np.unique(test_labels))
colors = plt.cm.get_cmap('tab20', num_classes)  # 更大的颜色区分度，使用'tab20'颜色映射
class_labels = ['{}'.format(i) for i in range(num_classes)]

selected_classes = np.random.choice(class_labels, 10, replace=False)

for i in selected_classes:
    indices = np.where(np.isin(test_labels, int(i)))
    plt.scatter(test_features_tsne[indices, 0], test_features_tsne[indices, 1], color=colors(int(i)), label=class_labels[int(i)], s=15)

plt.legend()
plt.xlabel('(d)')

xticks = np.arange(-40, 50, 10)
yticks = np.arange(-40, 50, 10)
plt.xticks(xticks)
plt.yticks(yticks)
plt.show()

